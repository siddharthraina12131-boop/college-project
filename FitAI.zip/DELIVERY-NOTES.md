# FitAI delivery notes

Updated 15 October 2026.

The finished source is included in this project folder and applied to the original Android Studio project at C:\Users\siddh\AndroidStudioProjects\FitAI. FitAI-original-backup.zip preserves the original source and build configuration.

## Verified
- Android debug APK builds successfully, minSdk 24, version 1.1 (code 2).
- Six JVM unit tests pass (including the original sample test).
- Four Android instrumentation tests pass on Samsung SM-E146B, Android 15.
- 233 held-out model vectors produce identical classifications in Python and Kotlin.
- Device tests cover workout completion, meal logging, weight entry, profile validation, activity recreation and profile data isolation.
- Screenshots of all five main tabs were reviewed for layout and readable content.
- Android lint reports zero errors. Warnings include existing dependency versions, template resources and minor style notices.
- Final status-bar and navigation-color refinements installed and visually verified on the phone. All four device tests pass on the final build. A first-frame startup race in the UI test was fixed by waiting for the Compose hierarchy.

## Model evaluation
- Source rows: 2,111; cleaned adult feature rows: 1,550.
- Train / validation / test: 1,085 / 232 / 233.
- Validation accuracy: Decision Tree 98.71%; Random Forest 99.57%; KNN 89.66%.
- Deployed Decision Tree test accuracy: 95.71%; macro-F1: 95.87%.
- Tree selected for compact and transparent offline inference; not claimed to outperform the forest.
- See ml/evaluation.json and README.md for data provenance, confusion matrix and important limitations.

## Scope
This is a working offline semester-project app. It does not have cloud login, an LLM chat service, medical validation, automatic model retraining or learned nutrition prescriptions. Body shape is captured and explained without making unsupported shape-specific health claims. Diet suggestions are curated, goal-aware examples. These refinements to the proposed blueprint are documented in README.md.

The APK is debug-signed for local installation and demonstration. Store publication requires your own release signing and publication process.

