# FitAI — Android college project

FitAI is a Kotlin / Jetpack Compose application with offline profiles, an educational ML classifier, rule-based workout and meal recommendations, and persistent activity tracking.

## Run in Android Studio
1. Open this FitAI folder as a project (not its app subfolder).
2. Allow Gradle sync. This project retains the original Android Gradle Plugin 9.4.1, Gradle 9.6.0, SDK 37 and Java 25 toolchain configuration. Android Studio's installed JBR is used on this machine.
3. Connect an Android phone running Android 7.0 or newer (API 24+) and allow USB debugging.
4. Select the app configuration and press Run.

The separately supplied FitAI-debug.apk is an installable development build. A Play Store release requires your own private signing key; none is invented or bundled.

## Features
- Up to three local profiles; original FitAI preference keys are preserved.
- Adult profile validation, optional sex/body-shape fields, activity, experience, goals and food preferences.
- BMI calculated from current height and weight without rounding before classification.
- On-device exported Decision Tree; no server, API key or connection required.
- Lower-impact workout selection based on profile, classifier output and difficulty feedback.
- Guided exercise checklist, one workout completion per calendar day, persisted across navigation/restarts.
- Vegetarian/non-vegetarian meal ideas with independent daily meal checkboxes.
- Current/yesterday-aware streak, unique active dates and recent workout history.
- Daily weight entries, trend chart and profile weight updates.
- Confirmed profile deletion, local storage, disabled cloud backup and device transfer of preference data.

## Blueprint mapping and scope decisions
| Blueprint item | Implementation |
| --- | --- |
| Profile, age, gender, height, weight | Profile editor; dataset sex encoding is explained and can be skipped |
| BMI and classification | Direct adult BMI computation; separate from educational model output |
| Body shape | Optional profile field and explicit explanation in recommendations; no unsupported claims about spot fat loss or a medically optimal body-shape workout |
| Fitness goals and activity | Workout intensity and nutrition guidance respond to the saved profile |
| Exercise recommendations | Transparent hybrid classifier + conservative rule engine |
| Diet recommendations | Curated meal examples with dietary substitutions and goal-specific advice; not a learned meal model or prescribed calorie plan |
| Tracking | Exercise and meal checks, workout dates, streak, weight history and feedback |
| Public dataset | UCI dataset 544, bundled in ml/data with source attribution |
| Preprocessing | Adult filtering, missing-value handling, deduplication, feature engineering and train-only KNN scaling |
| Multiple algorithms | Decision Tree, Random Forest and KNN compared on validation data |
| Evaluation | Separate test split, accuracy, macro-F1, per-class metrics and confusion matrix in ml/evaluation.json |
| Android integration | JSON model asset traversed locally in Kotlin; cross-language parity test |
| Feedback | Too hard selects a gentler plan; feedback does not retrain the classifier |

The app intentionally uses local SharedPreferences rather than introducing a backend. Generative AI is not required for these offline features. Profiles support ages 18–80. Adult BMI categories are restricted to ages 20+; ages 18–19 display an age-specific guidance label; the model falls back to rules outside its supported age/sex inputs. This is a semester demonstration, not a clinically validated fitness or nutrition service.

## ML reproduction
From the project root:

    python -m pip install -r ml/requirements.txt
    python ml/train.py

This regenerates app/src/main/assets/profile_model.json, model_parity.json and ml/evaluation.json. The parity vectors are public dataset rows, not user data.

The deployed tree is selected for compactness and transparency. The forest may score higher; the selection reason is recorded rather than claiming the tree is the best-scoring algorithm.

## Validation

    gradlew.bat testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
    gradlew.bat connectedDebugAndroidTest

Unit tests cover BMI boundaries, invalid values, recommendation fallback/intensity and streak behavior. Device tests cover model parity, profile isolation, persisted logs, idempotent workout completion and the daily UI journey. The device tests reserve IDs 9001–9003, clean those records and restore the prior active profile. They must not be interrupted while testing a user's installation.

See DELIVERY-NOTES.md for checks actually run and any remaining device verification.

## Data and health references
- Mendoza Palechor, F. and De la Hoz Manotas, A. (2019). Estimation of Obesity Levels Based On Eating Habits and Physical Condition. UCI Machine Learning Repository. https://doi.org/10.24432/C5H31Z. CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
- Source download: https://archive.ics.uci.edu/static/public/544/estimation+of+obesity+levels+based+on+eating+habits+and+physical+condition.zip
- Adult BMI categories and limitations: https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html
- General activity reference: https://www.cdc.gov/physical-activity/media/pdfs/Physical_Activity_Guidelines_2nd_edition.pdf

UCI reports 77% synthetic data. Height, weight and BMI closely determine the classification target. Related synthetic records may occur across splits, and there is no external population or clinical validation. The reported score measures dataset classification only, not recommendation safety, effectiveness or personalized health outcomes. Meals and exercise descriptions are curated examples, not observations or trained labels from UCI.

## Team
Siddharth Raina — 2026A1L002
Mahin Tickoo — 2025A1R149
Ayushmanjit Singh Raina — 2025A1R178
Semester 3 · Section A5 · AI/ML
