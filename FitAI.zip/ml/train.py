from pathlib import Path
import json, hashlib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report

ROOT=Path(__file__).resolve().parent
source=ROOT/'data/ObesityDataSet_raw_and_data_sinthetic.csv'
df=pd.read_csv(source)
raw=len(df)
df=df.dropna().drop_duplicates()
df=df[(df.Age>=20)&(df.Age<=65)&(df.Height>0)&(df.Weight>0)].copy()
df['bmi']=df.Weight/df.Height**2
df['sex']=df.Gender.map({'Female':0,'Male':1})
df['activity']=pd.cut(df.FAF,[-1,0.5,1.5,4],labels=[0,1,2]).astype(int)
features=['Age','Height','Weight','sex','activity','bmi']
# Deduplicate the actual feature vectors before splitting, not only complete rows.
df=df.drop_duplicates(subset=features)
X=df[features].to_numpy(); y=df.NObeyesdad.to_numpy()
Xtrain,Xhold,ytrain,yhold=train_test_split(X,y,test_size=.30,stratify=y,random_state=42)
Xval,Xtest,yval,ytest=train_test_split(Xhold,yhold,test_size=.5,stratify=yhold,random_state=43)
models={'Decision Tree':DecisionTreeClassifier(max_depth=7,min_samples_leaf=8,random_state=42),
 'Random Forest':RandomForestClassifier(n_estimators=80,max_depth=9,min_samples_leaf=4,random_state=42),
 'KNN':make_pipeline(StandardScaler(),KNeighborsClassifier(n_neighbors=9,weights='distance'))}
metrics={}
for name,m in models.items():
 m.fit(Xtrain,ytrain); p=m.predict(Xval)
 metrics[name]={'validation_accuracy':accuracy_score(yval,p),'validation_macro_f1':f1_score(yval,p,average='macro')}
# A compact tree is deployed for transparent, inspectable offline inference.
selected=models['Decision Tree']; pred=selected.predict(Xtest)
t=selected.tree_
asset={'name':'Decision Tree','features':features,'classes':selected.classes_.tolist(),'left':t.children_left.tolist(),'right':t.children_right.tolist(),'feature':t.feature.tolist(),'threshold':t.threshold.tolist(),'value':[int(np.argmax(v)) for v in t.value], 'source':'UCI 544; CC BY 4.0','test_accuracy':accuracy_score(ytest,pred)}
(ROOT.parent/'app/src/main/assets/profile_model.json').write_text(json.dumps(asset),encoding='utf-8')
# Cross-language parity vectors are checked by Android instrumentation tests.
vectors=[{'input':x.tolist(),'expected':str(p)} for x,p in zip(Xtest, pred)]
(ROOT.parent/'app/src/main/assets/model_parity.json').write_text(json.dumps(vectors),encoding='utf-8')
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'raw_rows':raw,'clean_adult_rows':len(df),'train':len(Xtrain),'validation':len(Xval),'test':len(Xtest),'seed':42,'features':features,'comparison':metrics,'deployed':'Decision Tree (chosen for compactness and explainability, not necessarily highest accuracy)','test_accuracy':accuracy_score(ytest,pred),'test_macro_f1':f1_score(ytest,pred,average='macro'),'classes':selected.classes_.tolist(),'confusion_matrix':confusion_matrix(ytest,pred,labels=selected.classes_).tolist(),'classification_report':classification_report(ytest,pred,output_dict=True),'limitations':['UCI data is 77% synthetic; related synthetic rows may cross splits, so metrics are optimistic.','Height, weight and BMI closely define the target; this is an educational classifier, not independent health prediction.','Dataset from Mexico, Peru and Colombia; no clinical or Indian-population validation.','Activity mapping is approximate; sex field only supports the source binary categories.','Model does not learn effective workouts or diets. Recommendations are explicit conservative rules using model output and user preferences.']}
(ROOT/'evaluation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['classification_report','confusion_matrix']},indent=2))
