package com.siddharth.fitai

import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FitnessUiTest {
    @get:Rule val compose = createEmptyComposeRule()

    private fun screenshot(name: String) {
        compose.waitForIdle()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val bitmap = instrumentation.uiAutomation.takeScreenshot()
        val file = File(instrumentation.targetContext.getExternalFilesDir(null), "fitai-$name.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    @Test
    fun dailyJourneyAndRestart() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = FitnessStore(context)
        val previous = store.active()?.id
        val p =
            FitnessProfile(
                id = 9003,
                name = "Alex",
                age = "24",
                height = "175",
                weight = "70",
                gender = "Male",
            )
        store.delete(p.id)
        store.save(p)
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            // A physical device can resume before its first Compose frame is attached.
            compose.waitUntil(timeoutMillis = 10_000) {
                runCatching {
                    compose.onAllNodesWithText("Hello, Alex.").fetchSemanticsNodes().isNotEmpty()
                }.getOrDefault(false)
            }
            compose.onNodeWithText("Hello, Alex.").assertIsDisplayed()
            screenshot("today")
            compose.onNodeWithText("Train").performClick()
            compose.onNodeWithText("Today's workout").assertIsDisplayed()
            screenshot("train")
            for (i in 0..5) compose.onAllNodes(isToggleable())[i].performScrollTo().performClick()
            compose.onNodeWithText("Complete today's workout").performScrollTo().performClick()
            compose.onNodeWithText("Workout saved for today").assertExists()
            compose.onNodeWithText("Meals").performClick()
            compose.onAllNodes(isToggleable())[0].performScrollTo().performClick()
            compose.onNodeWithText("Simple, balanced meals").performScrollTo()
            screenshot("meals")
            compose.onNodeWithText("Progress").performClick()
            compose.onNodeWithText("Today's weight (kg)").performScrollTo().performTextInput("71.2")
            compose.onNodeWithText("Save weight").performScrollTo().performClick()
            compose.onNodeWithText("71.2 kg").assertExists()
            compose.onNodeWithText("Your progress").performScrollTo()
            screenshot("progress")
            scenario.recreate()
            compose.onNodeWithText("Progress").assertExists()
            compose.onNodeWithText("Train").performClick()
            compose.onNodeWithText("Workout saved for today").performScrollTo().assertIsNotEnabled()
            compose.onNodeWithText("Profile").performClick()
            screenshot("profile")
            compose.onNodeWithText("Edit profile & preferences").performScrollTo().performClick()
            compose.onNodeWithText("Name").performTextClearance()
            compose.onNodeWithText("Save my profile").performScrollTo().performClick()
            compose.onNodeWithText("Please enter your name.").assertExists()
            compose.onNodeWithText("Cancel").performScrollTo().performClick()
        } finally {
            scenario.close()
            store.delete(p.id)
            store.select(previous)
        }
    }
}
