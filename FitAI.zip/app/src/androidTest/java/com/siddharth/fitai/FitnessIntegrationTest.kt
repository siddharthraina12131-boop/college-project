package com.siddharth.fitai

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FitnessIntegrationTest {
    private val context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun exportedModelMatchesPythonOnAllTestRows() {
        val model = ProfileModel(context)
        val cases =
            JSONArray(
                context.assets.open("model_parity.json").bufferedReader().use { it.readText() }
            )
        assertTrue(cases.length() > 100)
        for (i in 0 until cases.length()) {
            val c = cases.getJSONObject(i)
            val a = c.getJSONArray("input")
            assertEquals(
                "Test row $i",
                c.getString("expected"),
                model.predict(DoubleArray(a.length()) { a.getDouble(it) }),
            )
        }
    }

    @Test
    fun persistenceIsolationAndIdempotentCompletion() {
        // Use reserved test IDs and clean up only these records.
        val store = FitnessStore(context)
        val active = store.active()?.id
        val a =
            FitnessProfile(id = 9001, name = "Test A", age = "24", height = "175", weight = "70")
        val b = a.copy(id = 9002, name = "Test B")
        try {
            store.save(a)
            store.save(b)
            store.complete(a.id)
            store.complete(a.id)
            assertEquals(1, store.completedCount(a.id))
            assertEquals(0, store.completedCount(b.id))
            store.toggle(a.id, "meal", "Breakfast")
            val reopened = FitnessStore(context)
            assertTrue("Breakfast" in reopened.checks(a.id, "meal"))
            assertTrue(reopened.checks(b.id, "meal").isEmpty())
            reopened.logWeight(a.id, 71.0)
            reopened.logWeight(a.id, 72.0)
            assertEquals(1, reopened.weights(a.id).size)
            assertEquals("72.0", reopened.load(a.id).weight)
            reopened.delete(a.id)
            assertFalse(reopened.profiles().any { it.id == a.id })
            assertTrue(reopened.profiles().any { it.id == b.id })
        } finally {
            store.delete(a.id)
            store.delete(b.id)
            store.select(active)
        }
    }
}
