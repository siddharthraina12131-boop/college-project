package com.siddharth.fitai

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import org.junit.Assert.*
import org.junit.Test

class FitnessLogicTest {
    private val profile =
        FitnessProfile(
            name = "Test",
            age = "24",
            height = "175",
            weight = "70",
            gender = "Male",
            activity = "Moderate",
            experience = "Intermediate",
        )

    @Test
    fun bmiUsesUnroundedValue() {
        assertEquals(22.857142, profile.bmi, 0.00001)
        assertEquals("Healthy range", bmiCategory(24.999))
        assertEquals("Overweight", bmiCategory(25.0))
        assertEquals("Obesity range", bmiCategory(30.0))
    }

    @Test
    fun rejectsInvalidAndNonFiniteInput() {
        listOf("NaN", "Infinity", "-1", "0", "251").forEach {
            assertNotNull(profile.copy(weight = it).error())
        }
        assertNotNull(profile.copy(age = "17").error())
        assertNotNull(profile.copy(name = " ").error())
        assertNull(profile.error())
        assertEquals("Age-specific guidance", profileBmiCategory(profile.copy(age = "19")))
    }

    @Test
    fun feedbackAndModelMakePlanGentler() {
        assertEquals(30, makePlan(profile, null).minutes)
        assertEquals(20, makePlan(profile, null, "Too hard").minutes)
        assertEquals(20, makePlan(profile, "Obesity_Type_I").minutes)
    }

    @Test
    fun beginnerNeverGetsAdvancedPlan() {
        assertEquals(
            "Chair squats",
            makePlan(profile.copy(experience = "Beginner"), null).exercises[1].name,
        )
    }

    @Test
    fun streakAllowsTodayToBeIncomplete() {
        val c = Calendar.getInstance()
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        c.add(Calendar.DAY_OF_YEAR, -1)
        val yesterday = f.format(c.time)
        c.add(Calendar.DAY_OF_YEAR, -1)
        assertEquals(2, streakFor(setOf(yesterday, f.format(c.time))))
        assertEquals(0, streakFor(emptySet()))
    }
}
