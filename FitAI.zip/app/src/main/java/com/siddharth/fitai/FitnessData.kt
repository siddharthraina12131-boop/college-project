package com.siddharth.fitai

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

data class FitnessProfile(
    val id: Int = 0,
    val name: String = "",
    val age: String = "",
    val height: String = "",
    val weight: String = "",
    val gender: String = "Prefer not to say",
    val activity: String = "Low",
    val experience: String = "Beginner",
    val goal: String = "General Fitness",
    val shape: String = "Not Sure",
    val diet: String = "Vegetarian",
) {
    val bmi: Double
        get() =
            (weight.toDoubleOrNull() ?: 0.0) /
                (((height.toDoubleOrNull() ?: 1.0) / 100).let { it * it })

    fun error(): String? =
        when {
            name.trim().isEmpty() -> "Please enter your name."
            name.length > 50 -> "Please keep your name under 50 characters."
            age.toIntOrNull() !in 18..80 -> "This adult wellness app supports ages 18–80."
            height.toDoubleOrNull()?.let { it.isFinite() && it in 120.0..230.0 } != true ->
                "Enter height between 120 and 230 cm."
            weight.toDoubleOrNull()?.let { it.isFinite() && it in 30.0..250.0 } != true ->
                "Enter weight between 30 and 250 kg."
            else -> null
        }
}

fun bmiCategory(bmi: Double) =
    when {
        bmi < 18.5 -> "Underweight"
        bmi < 25 -> "Healthy range"
        bmi < 30 -> "Overweight"
        else -> "Obesity range"
    }

fun profileBmiCategory(p: FitnessProfile): String =
    if (p.age.toInt() < 20) "Age-specific guidance" else bmiCategory(p.bmi)

fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)

fun streakFor(dates: Set<String>): Int {
    val calendar = Calendar.getInstance()
    val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    if (format.format(calendar.time) !in dates) calendar.add(Calendar.DAY_OF_YEAR, -1)
    var count = 0
    while (format.format(calendar.time) in dates) {
        count++
        calendar.add(Calendar.DAY_OF_YEAR, -1)
    }
    return count
}

data class Exercise(val name: String, val dose: String, val guidance: String)

data class FitnessPlan(
    val title: String,
    val minutes: Int,
    val exercises: List<Exercise>,
    val explanation: String,
    val modelLabel: String,
)

class ProfileModel(context: Context) {
    private val data =
        runCatching {
                JSONObject(
                    context.assets.open("profile_model.json").bufferedReader().use { it.readText() }
                )
            }
            .getOrNull()

    fun predict(input: DoubleArray): String? {
        val d = data ?: return null
        var node = 0
        repeat(d.getJSONArray("left").length()) {
            val left = d.getJSONArray("left").getInt(node)
            if (left < 0)
                return d.getJSONArray("classes").getString(d.getJSONArray("value").getInt(node))
            val f = d.getJSONArray("feature").getInt(node)
            node =
                if (input[f] <= d.getJSONArray("threshold").getDouble(node)) left
                else d.getJSONArray("right").getInt(node)
        }
        return null
    }

    fun classify(p: FitnessProfile): String? {
        if (p.error() != null || p.age.toInt() !in 20..61 || p.gender == "Prefer not to say")
            return null
        return predict(
            doubleArrayOf(
                p.age.toDouble(),
                p.height.toDouble() / 100,
                p.weight.toDouble(),
                if (p.gender == "Male") 1.0 else 0.0,
                listOf("Low", "Moderate", "High").indexOf(p.activity).coerceAtLeast(0).toDouble(),
                p.bmi,
            )
        )
    }
}

fun makePlan(p: FitnessProfile, modelLabel: String?, feedback: String = ""): FitnessPlan {
    val gentle =
        p.experience == "Beginner" ||
            p.activity == "Low" ||
            p.bmi >= 30 ||
            p.age.toInt() >= 60 ||
            modelLabel?.startsWith("Obesity") == true ||
            feedback == "Too hard"
    val strength = p.goal == "Muscle Gain"
    val reps = if (gentle) "2 × 8 repetitions" else "3 × 10 repetitions"
    val exercises =
        mutableListOf(
            Exercise(
                "Easy warm-up",
                "5 minutes",
                "Walk gently and circle your shoulders. Increase the pace gradually.",
            ),
            Exercise(
                if (gentle) "Chair squats" else "Bodyweight squats",
                reps,
                "Keep feet about hip-width apart. Sit back with control; use a stable chair for support.",
            ),
            Exercise(
                if (gentle) "Wall push-ups" else "Incline push-ups",
                reps,
                "Use a stable wall or counter. Keep your body in a straight line and move slowly.",
            ),
            Exercise(
                "Glute bridges",
                reps,
                "Lie on your back with knees bent. Lift your hips gently without arching your lower back.",
            ),
            Exercise(
                if (strength) "Bird dog" else "Comfortable walk",
                if (strength) "2 × 8 each side" else if (gentle) "5 minutes" else "10 minutes",
                if (strength)
                    "From hands and knees, extend the opposite arm and leg. Keep your back still."
                else "Choose a pace where you can still speak comfortably.",
            ),
            Exercise(
                "Cool-down",
                "3 minutes",
                "Slow your pace and stretch gently without bouncing.",
            ),
        )
    val explanation =
        "${p.goal} • ${p.experience} • ${p.activity.lowercase()} activity. " +
            (if (gentle) "A lower-impact starting plan is selected from your profile and feedback."
            else "A moderate bodyweight plan balances strength and movement.") +
            " Body shape is an optional preference, not a health diagnosis; balanced full-body training is used for ${p.shape.lowercase()} profiles."
    return FitnessPlan(
        if (strength) "Build your foundation"
        else if (gentle) "Move at your pace" else "Your daily balance",
        if (gentle) 20 else 30,
        exercises,
        explanation,
        modelLabel?.replace('_', ' ') ?: "Rule-based fallback",
    )
}

class FitnessStore(context: Context) {
    private val prefs = context.getSharedPreferences("FitAI", Context.MODE_PRIVATE)

    private fun key(id: Int, k: String) = "profile_${id}_$k"

    init {
        if (!prefs.getBoolean("multi_profile_migrated", false)) {
            val e = prefs.edit()
            if (!prefs.getString("name", "").isNullOrBlank()) {
                prefs.all.forEach { (k, v) ->
                    when (v) {
                        is String -> e.putString(key(0, k), v)
                        is Int -> e.putInt(key(0, k), v)
                        is Boolean -> e.putBoolean(key(0, k), v)
                        is Set<*> -> e.putStringSet(key(0, k), v.filterIsInstance<String>().toSet())
                    }
                }
                e.putStringSet("profile_ids", setOf("0")).putString("active_profile_id", "0")
            }
            e.putBoolean("multi_profile_migrated", true).apply()
        }
    }

    fun profiles() =
        prefs
            .getStringSet("profile_ids", emptySet())
            .orEmpty()
            .mapNotNull { it.toIntOrNull() }
            .sorted()
            .map { load(it) }

    fun active() =
        prefs.getString("active_profile_id", null)?.toIntOrNull()?.let { id ->
            profiles().find { it.id == id }
        }

    fun select(id: Int?) {
        prefs
            .edit()
            .apply {
                if (id == null) remove("active_profile_id")
                else putString("active_profile_id", id.toString())
            }
            .apply()
    }

    fun text(id: Int, k: String, default: String = "") =
        prefs.getString(key(id, k), default) ?: default

    fun load(id: Int): FitnessProfile =
        FitnessProfile(
            id,
            text(id, "name"),
            text(id, "age"),
            text(id, "height"),
            text(id, "weight"),
            text(id, "gender", "Prefer not to say").ifBlank { "Prefer not to say" },
            text(id, "activity_level", "Low").ifBlank { "Low" },
            text(id, "experience", "Beginner").ifBlank { "Beginner" },
            text(id, "goal", "General Fitness").ifBlank { "General Fitness" },
            text(id, "body_shape", "Not Sure").ifBlank { "Not Sure" },
            text(id, "diet_preference", "Vegetarian").ifBlank { "Vegetarian" },
        )

    fun save(p: FitnessProfile) {
        require(p.error() == null)
        val e = prefs.edit()
        mapOf(
                "name" to p.name.trim(),
                "age" to p.age,
                "height" to p.height,
                "weight" to p.weight,
                "bmi" to p.bmi.toString(),
                "gender" to p.gender,
                "activity_level" to p.activity,
                "experience" to p.experience,
                "goal" to p.goal,
                "body_shape" to p.shape,
                "diet_preference" to p.diet,
            )
            .forEach { (k, v) -> e.putString(key(p.id, k), v) }
        e.putBoolean(key(p.id, "profile_complete"), true)
            .putStringSet(
                "profile_ids",
                (profiles().map { it.id.toString() } + p.id.toString()).toSet(),
            )
            .putString("active_profile_id", p.id.toString())
            .apply()
        logWeight(p.id, p.weight.toDouble())
    }

    fun delete(id: Int) {
        val e = prefs.edit()
        prefs.all.keys.filter { it.startsWith("profile_${id}_") }.forEach { e.remove(it) }
        e.putStringSet(
            "profile_ids",
            profiles().filter { it.id != id }.map { it.id.toString() }.toSet(),
        )
        if (active()?.id == id) e.remove("active_profile_id")
        e.apply()
    }

    fun dates(id: Int) = prefs.getStringSet(key(id, "workout_dates"), emptySet()).orEmpty().toSet()

    fun completedCount(id: Int) =
        maxOf(dates(id).size, prefs.getInt(key(id, "completed_workouts"), 0))

    fun complete(id: Int) {
        val dates = dates(id)
        if (today() !in dates)
            prefs
                .edit()
                .putStringSet(key(id, "workout_dates"), dates + today())
                .putInt(key(id, "completed_workouts"), completedCount(id) + 1)
                .apply()
    }

    fun checks(id: Int, kind: String) =
        prefs.getStringSet(key(id, "${kind}_${today()}"), emptySet()).orEmpty().toSet()

    fun toggle(id: Int, kind: String, item: String) {
        val old = checks(id, kind)
        prefs
            .edit()
            .putStringSet(
                key(id, "${kind}_${today()}"),
                if (item in old) old - item else old + item,
            )
            .apply()
    }

    fun feedback(id: Int, value: String) {
        prefs.edit().putString(key(id, "feedback"), value).apply()
    }

    fun weights(id: Int): List<Pair<String, Double>> =
        runCatching {
                val a = JSONArray(text(id, "weight_history", "[]"))
                (0 until a.length()).map {
                    a.getJSONObject(it).let { v -> v.getString("date") to v.getDouble("weight") }
                }
            }
            .getOrDefault(emptyList())

    fun logWeight(id: Int, w: Double) {
        require(w.isFinite() && w in 30.0..250.0)
        val list =
            (weights(id).filter { it.first != today() } + (today() to w))
                .sortedBy { it.first }
                .takeLast(365)
        val array = JSONArray()
        list.forEach { (date, weight) ->
            array.put(JSONObject().put("date", date).put("weight", weight))
        }
        prefs
            .edit()
            .putString(key(id, "weight_history"), array.toString())
            .putString(key(id, "weight"), w.toString())
            .apply()
    }
}
