package com.siddharth.fitai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.util.Locale

private val Ink = Color(0xFF152D2A)
private val Green = Color(0xFF136B56)
private val Mint = Color(0xFFE3F2E9)
private val Paper = Color(0xFFF5F7F3)
private val Muted = Color(0xFF5B6E68)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        setContent { FitAIApp() }
    }
}

@Composable
fun FitAIApp() {
    MaterialTheme(
        colorScheme =
            lightColorScheme(
                primary = Green,
                onPrimary = Color.White,
                secondary = Green,
            secondaryContainer = Mint,
            onSecondaryContainer = Green,
                background = Paper,
                surface = Color.White,
                onSurface = Ink,
                onBackground = Ink,
                primaryContainer = Mint,
                onPrimaryContainer = Ink,
            )
    ) {
        val context = LocalContext.current
        val store = remember { FitnessStore(context) }
        val model = remember { ProfileModel(context) }
        var revision by remember { mutableIntStateOf(0) }
        var selected by rememberSaveable { mutableStateOf(store.active()?.id) }
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var editing by rememberSaveable { mutableStateOf(false) }
        var newProfile by rememberSaveable { mutableStateOf(false) }
        var deleteId by remember { mutableStateOf<Int?>(null) }
        val lifecycle = LocalLifecycleOwner.current.lifecycle
        DisposableEffect(lifecycle) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) revision++
            }
            lifecycle.addObserver(observer)
            onDispose { lifecycle.removeObserver(observer) }
        }
        val profiles = remember(revision) { store.profiles() }
        val profile = profiles.find { it.id == selected }
        BackHandler(editing || selected != null && tab != 0) {
            if (editing) {
                editing = false
                newProfile = false
            } else tab = 0
        }
        if (deleteId != null)
            AlertDialog(
                onDismissRequest = { deleteId = null },
                title = { Text("Delete this profile?") },
                text = {
                    Text(
                        "This removes this profile and its saved activity and weight history from this device."
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            store.delete(deleteId!!)
                            if (selected == deleteId) selected = null
                            deleteId = null
                            revision++
                        }
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancel") } },
            )
        Surface(Modifier.fillMaxSize(), color = Paper) {
            when {
                editing || profile != null && profile.error() != null -> {
                    val seed =
                        if (newProfile)
                            FitnessProfile(id = (0..99).first { n -> profiles.none { it.id == n } })
                        else profile ?: FitnessProfile()
                    ProfileEditor(
                        seed,
                        onCancel = {
                            editing = false
                            newProfile = false
                            if (profile?.error() != null) {
                                selected = null
                                store.select(null)
                            }
                        },
                        onSave = {
                            store.save(it)
                            selected = it.id
                            revision++
                            editing = false
                            newProfile = false
                            tab = 0
                        },
                    )
                }
                profile == null ->
                    Page {
                        Spacer(Modifier.height(32.dp))
                        Text(
                            "FIT AI",
                            color = Green,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 4.sp,
                        )
                        Text(
                            "Small steps.\nStronger you.",
                            fontSize = 42.sp,
                            lineHeight = 46.sp,
                            fontWeight = FontWeight.Bold,
                            color = Ink,
                        )
                        Text(
                            "Your personal space for movement, balanced meals and everyday progress.",
                            color = Muted,
                            fontSize = 17.sp,
                        )
                        Hero(
                            "Built around you",
                            "Personal plans. Real progress.",
                            "Works offline • Your data stays on this device",
                        )
                        if (profiles.isNotEmpty()) SectionTitle("Choose your profile")
                        profiles.forEach { p ->
                            Panel {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(p.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                        Text(p.goal, color = Muted)
                                    }
                                    TextButton(
                                        onClick = {
                                            store.select(p.id)
                                            selected = p.id
                                            tab = 0
                                        }
                                    ) {
                                        Text("Open")
                                    }
                                    IconButton(onClick = { deleteId = p.id }) {
                                        Icon(Icons.Outlined.Delete, "Delete ${p.name}")
                                    }
                                }
                            }
                        }
                        Button(
                            onClick = {
                                newProfile = true
                                editing = true
                            },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                            enabled = profiles.size < 3,
                        ) {
                            Text(if (profiles.isEmpty()) "Create your plan" else "Add profile")
                        }
                        Text(
                            "Designed for adults 18–80. General wellness guidance, not medical care. Up to three local profiles.",
                            color = Muted,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                else -> {
                    val prediction = remember(profile) { model.classify(profile) }
                    val plan = makePlan(profile, prediction, store.text(profile.id, "feedback"))
                    Scaffold(
                        containerColor = Paper,
                        bottomBar = {
                            NavigationBar(containerColor = Color.White) {
                                val names = listOf("Today", "Train", "Meals", "Progress", "Profile")
                                val icons =
                                    listOf(
                                        Icons.Outlined.Home,
                                        Icons.Outlined.FitnessCenter,
                                        Icons.Outlined.Restaurant,
                                        Icons.Outlined.Insights,
                                        Icons.Outlined.Person,
                                    )
                                names.forEachIndexed { i, name ->
                                    NavigationBarItem(
                                        selected = tab == i,
                                        onClick = { tab = i },
                                        icon = { Icon(icons[i], name) },
                                        label = { Text(name, fontSize = 11.sp) },
                                    )
                                }
                            }
                        },
                    ) { padding ->
                        key(profile.id, tab) {
                            Page(Modifier.padding(padding).consumeWindowInsets(padding)) {
                                when (tab) {
                                    0 -> {
                                        Eyebrow("YOUR DAILY RESET")
                                        Text(
                                            "Hello, ${profile.name.substringBefore(' ')}.",
                                            fontSize = 32.sp,
                                            fontWeight = FontWeight.Bold,
                                        )
                                        Text("A little progress, every day.", color = Muted)
                                        Hero(
                                            profile.goal,
                                            plan.title,
                                            "${plan.minutes} min • ${profile.experience} • No gym needed",
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Stat(
                                                "BMI",
                                                String.format(Locale.US, "%.1f", profile.bmi),
                                                profileBmiCategory(profile),
                                                Modifier.weight(1f),
                                            )
                                            Stat(
                                                "STREAK",
                                                "${streakFor(store.dates(profile.id))}",
                                                "active days",
                                                Modifier.weight(1f),
                                            )
                                        }
                                        SectionTitle("Your next step")
                                        ActionPanel(
                                            "Move your body",
                                            "${plan.exercises.size} guided exercises",
                                            Icons.Outlined.FitnessCenter,
                                        ) {
                                            tab = 1
                                        }
                                        ActionPanel(
                                            "Fuel your day",
                                            "Balanced meal ideas for your preference",
                                            Icons.Outlined.Restaurant,
                                        ) {
                                            tab = 2
                                        }
                                        Panel {
                                            Eyebrow("WHY THIS PLAN")
                                            Text(plan.explanation, color = Muted)
                                            Text(
                                                "Offline model: ${plan.modelLabel}",
                                                fontWeight = FontWeight.SemiBold,
                                            )
                                            Text(
                                                "The model estimates a dataset category. Workout and meal choices use explicit wellness rules, not clinical predictions.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Muted,
                                            )
                                        }
                                    }
                                    1 -> {
                                        Eyebrow("MOVE WITH INTENTION")
                                        Heading("Today's workout", plan.title)
                                        Hero(
                                            "${plan.minutes}-minute guide",
                                            if (today() in store.dates(profile.id))
                                                "You showed up today."
                                            else "One exercise at a time.",
                                            "Rest when needed • Keep a comfortable pace",
                                        )
                                        val checks = store.checks(profile.id, "exercise")
                                        val done = today() in store.dates(profile.id)
                                        LinearProgressIndicator(
                                            progress = {
                                                checks.size.toFloat() / plan.exercises.size
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            color = Green,
                                        )
                                        Text(
                                            "${checks.size} of ${plan.exercises.size} exercises checked",
                                            color = Muted,
                                        )
                                        plan.exercises.forEachIndexed { i, e ->
                                            Panel {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Checkbox(
                                                        checked = i.toString() in checks,
                                                        onCheckedChange = {
                                                            store.toggle(
                                                                profile.id,
                                                                "exercise",
                                                                i.toString(),
                                                            )
                                                            revision++
                                                        },
                                                        enabled = !done,
                                                    )
                                                    Column(Modifier.weight(1f)) {
                                                        Text(
                                                            e.name,
                                                            fontSize = 18.sp,
                                                            fontWeight = FontWeight.Bold,
                                                        )
                                                        Text(
                                                            e.dose,
                                                            color = Green,
                                                            fontWeight = FontWeight.SemiBold,
                                                        )
                                                    }
                                                }
                                                Text(e.guidance, color = Muted)
                                            }
                                        }
                                        Button(
                                            onClick = {
                                                store.complete(profile.id)
                                                revision++
                                            },
                                            enabled = !done && checks.size == plan.exercises.size,
                                            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                                        ) {
                                            Text(
                                                if (done) "Workout saved for today"
                                                else "Complete today's workout"
                                            )
                                        }
                                        if (done) {
                                            SectionTitle("How did it feel?")
                                            Choice(
                                                "Your feedback",
                                                listOf("Too easy", "Just right", "Too hard"),
                                                store.text(profile.id, "feedback"),
                                            ) {
                                                store.feedback(profile.id, it)
                                                revision++
                                            }
                                            Text(
                                                "Too hard switches your plan to a gentler option. Other feedback keeps the current progression.",
                                                color = Muted,
                                                style = MaterialTheme.typography.bodySmall,
                                            )
                                        }
                                        Text(
                                            "Stop if you feel pain, dizziness or unusual shortness of breath. Use rest days between strength sessions. If you have an injury or health condition, seek individual guidance.",
                                            color = Muted,
                                            style = MaterialTheme.typography.bodySmall,
                                        )
                                    }
                                    2 -> {
                                        Eyebrow("NOURISH YOUR DAY")
                                        Heading("Simple, balanced meals", profile.diet)
                                        Hero(
                                            profile.goal,
                                            "Make room for balance.",
                                            "Vegetables + protein + grains + variety",
                                        )
                                        val nonveg = profile.diet == "Non-Vegetarian"
                                        val meals =
                                            listOf(
                                                Triple(
                                                    "Breakfast",
                                                    "Oats, fruit & yogurt",
                                                    "Try a bowl of oats, plain yogurt and seasonal fruit. Swap yogurt for an unsweetened plant alternative if preferred.",
                                                ),
                                                Triple(
                                                    "Lunch",
                                                    if (nonveg) "Chicken, rice & vegetables"
                                                    else "Dal, rice & vegetables",
                                                    "Combine a protein source with rice or roti and a generous side of vegetables.",
                                                ),
                                                Triple(
                                                    "Snack",
                                                    "Fruit & a handful of nuts",
                                                    "Choose fruit, plain curd or nuts according to your appetite and tolerances.",
                                                ),
                                                Triple(
                                                    "Dinner",
                                                    if (nonveg) "Eggs or fish with roti"
                                                    else "Paneer or tofu with roti",
                                                    "Add cooked vegetables and vary your protein sources through the week.",
                                                ),
                                            )
                                        val eaten = store.checks(profile.id, "meal")
                                        meals.forEach { (label, title, description) ->
                                            Panel {
                                                Eyebrow(label.uppercase())
                                                Text(
                                                    title,
                                                    fontSize = 21.sp,
                                                    fontWeight = FontWeight.Bold,
                                                )
                                                Text(description, color = Muted)
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Checkbox(
                                                        checked = label in eaten,
                                                        onCheckedChange = {
                                                            store.toggle(profile.id, "meal", label)
                                                            revision++
                                                        },
                                                    )
                                                    Text("Meal logged")
                                                }
                                            }
                                        }
                                        Panel {
                                            SectionTitle("Your food focus")
                                            Text(
                                                when {
                                                    profile.bmi < 18.5 &&
                                                        profile.goal == "Weight Loss" ->
                                                        "Weight-loss restriction is not suggested at a low BMI. Discuss an appropriate goal with a qualified professional."
                                                    profile.goal == "Muscle Gain" ->
                                                        "Include a protein source in each main meal and eat enough to support training."
                                                    profile.goal == "Weight Loss" ->
                                                        "Build balanced meals and a sustainable routine. Avoid skipping meals or extreme restrictions."
                                                    else ->
                                                        "Enjoy a varied diet with vegetables, fruit, grains and protein."
                                                },
                                                color = Muted,
                                            )
                                            Text(
                                                "These are meal ideas, not a prescribed calorie plan. Adjust portions to your needs. Check ingredients for allergies. No Preference uses the vegetarian base; alternatives can be chosen in Profile.",
                                                color = Muted,
                                                style = MaterialTheme.typography.bodySmall,
                                            )
                                        }
                                    }
                                    3 -> {
                                        Eyebrow("CONSISTENCY COUNTS")
                                        Heading(
                                            "Your progress",
                                            "Every completed day is a step forward.",
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Stat(
                                                "WORKOUTS",
                                                "${store.completedCount(profile.id)}",
                                                "saved sessions",
                                                Modifier.weight(1f),
                                            )
                                            Stat(
                                                "ACTIVE DAYS",
                                                "${store.dates(profile.id).size}",
                                                "unique dates",
                                                Modifier.weight(1f),
                                            )
                                        }
                                        WeightPanel(profile, store) { revision++ }
                                        SectionTitle("Recent activity")
                                        val dates =
                                            store.dates(profile.id).sortedDescending().take(10)
                                        if (dates.isEmpty())
                                            Panel {
                                                Text(
                                                    "Your first workout starts the story.",
                                                    fontWeight = FontWeight.Bold,
                                                )
                                                Text(
                                                    "Complete the exercise checklist in Train to record your first active day.",
                                                    color = Muted,
                                                )
                                            }
                                        dates.forEach { date ->
                                            Panel {
                                                Row(
                                                    Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                ) {
                                                    Text(date)
                                                    Text(
                                                        "Workout complete",
                                                        color = Green,
                                                        fontWeight = FontWeight.SemiBold,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    4 -> {
                                        Eyebrow("MADE FOR YOU")
                                        Heading(profile.name, "Your goals, your pace.")
                                        Hero(
                                            profile.goal,
                                            "${profile.weight} kg  •  ${profile.height} cm",
                                            "${profile.age} years • ${profile.activity} activity",
                                        )
                                        Panel {
                                            Text(
                                                "${profile.experience} • ${profile.diet}",
                                                fontWeight = FontWeight.Bold,
                                            )
                                            Text("Body shape: ${profile.shape}", color = Muted)
                                            Text(
                                                "BMI ${String.format(Locale.US,"%.1f",profile.bmi)} · ${profileBmiCategory(profile)}",
                                                color = Muted,
                                            )
                                            Text(
                                                "BMI is a screening measure, not body composition. For ages 18–19, age-specific clinical interpretation is needed.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Muted,
                                            )
                                        }
                                        Button(
                                            onClick = { editing = true },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text("Edit profile & preferences")
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                store.select(null)
                                                selected = null
                                                tab = 0
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text("Switch profile")
                                        }
                                        Panel {
                                            SectionTitle("About FitAI")
                                            Text(
                                                "An offline AI/ML college project by Siddharth Raina, Mahin Tickoo and Ayushmanjit Singh Raina. Semester 3 · Section A5.",
                                                color = Muted,
                                            )
                                            Text(
                                                "Decision Tree classification trained on UCI dataset 544. Source: Mendoza Palechor & De la Hoz Manotas (2019), CC BY 4.0. Dataset is 77% synthetic. This educational model is not clinically validated.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Muted,
                                            )
                                            Text(
                                                "Your profile and logs stay in this app's local storage. Uninstalling removes them; there is no cloud account or automatic backup.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Muted,
                                            )
                                        }
                                        TextButton(onClick = { deleteId = profile.id }) {
                                            Text(
                                                "Delete this profile",
                                                color = MaterialTheme.colorScheme.error,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content,
    )
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
    ) {
        Column(
            Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content,
        )
    }
}

@Composable
private fun Eyebrow(text: String) {
    Text(
        text,
        color = Green,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.8.sp,
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun Heading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted)
    }
}

@Composable
private fun Hero(label: String, title: String, subtitle: String) {
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Ink, Green)), RoundedCornerShape(26.dp))
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            label.uppercase(),
            color = Color(0xFFB8E5C8),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
        )
        Text(
            title,
            color = Color.White,
            fontSize = 27.sp,
            lineHeight = 32.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(subtitle, color = Color(0xFFD6E9DF), fontSize = 14.sp)
    }
}

@Composable
private fun Stat(label: String, value: String, caption: String, modifier: Modifier) {
    Card(
        modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Mint),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Eyebrow(label)
            Text(value, fontSize = 31.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(caption, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ActionPanel(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(subtitle, color = Muted, fontSize = 13.sp)
            }
            Icon(Icons.Outlined.ChevronRight, null, tint = Green)
        }
    }
}

@Composable
private fun Choice(
    label: String,
    options: List<String>,
    value: String,
    onChange: (String) -> Unit,
) {
    Column {
        Text(label, fontWeight = FontWeight.SemiBold)
        options.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { option ->
                    FilterChip(
                        selected = value == option,
                        onClick = { onChange(option) },
                        label = { Text(option) },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ProfileEditor(
    seed: FitnessProfile,
    onCancel: () -> Unit,
    onSave: (FitnessProfile) -> Unit,
) {
    var name by rememberSaveable(seed.id) { mutableStateOf(seed.name) }
    var age by rememberSaveable(seed.id) { mutableStateOf(seed.age) }
    var height by rememberSaveable(seed.id) { mutableStateOf(seed.height) }
    var weight by rememberSaveable(seed.id) { mutableStateOf(seed.weight) }
    var gender by rememberSaveable(seed.id) { mutableStateOf(seed.gender) }
    var activity by rememberSaveable(seed.id) { mutableStateOf(seed.activity) }
    var experience by rememberSaveable(seed.id) { mutableStateOf(seed.experience) }
    var goal by rememberSaveable(seed.id) { mutableStateOf(seed.goal) }
    var shape by rememberSaveable(seed.id) { mutableStateOf(seed.shape) }
    var diet by rememberSaveable(seed.id) { mutableStateOf(seed.diet) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    Page {
        Eyebrow("YOUR PERSONAL STARTING POINT")
        Heading("Build your profile", "A few details help us tailor your plan.")
        Field("Name", name, { name = it })
        Field("Age (18–80)", age, { age = it }, true)
        Field("Height (cm)", height, { height = it }, true)
        Field("Weight (kg)", weight, { weight = it }, true)
        Choice("Sex used by the dataset", listOf("Male", "Female", "Prefer not to say"), gender) {
            gender = it
        }
        Text(
            "Optional. Prefer not to say uses the rule-based plan without model classification.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
        )
        Choice("Activity level", listOf("Low", "Moderate", "High"), activity) { activity = it }
        Choice("Experience", listOf("Beginner", "Intermediate", "Advanced"), experience) {
            experience = it
        }
        Choice("Your goal", listOf("General Fitness", "Weight Loss", "Muscle Gain"), goal) {
            goal = it
        }
        Choice(
            "Body shape (optional)",
            listOf("Not Sure", "Apple", "Pear", "Rectangle", "Hourglass"),
            shape,
        ) {
            shape = it
        }
        Choice("Food preference", listOf("Vegetarian", "Non-Vegetarian", "No Preference"), diet) {
            diet = it
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                val p =
                    FitnessProfile(
                        seed.id,
                        name,
                        age,
                        height.replace(',', '.'),
                        weight.replace(',', '.'),
                        gender,
                        activity,
                        experience,
                        goal,
                        shape,
                        diet,
                    )
                error = p.error()
                if (error == null) onSave(p)
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
        ) {
            Text("Save my profile")
        }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    numeric: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions =
            KeyboardOptions(
                keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text
            ),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun WeightPanel(p: FitnessProfile, store: FitnessStore, onUpdate: () -> Unit) {
    var entry by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val weights = store.weights(p.id)
    Panel {
        SectionTitle("Weight journal")
        Text("Track a trend, not a single number. One entry per day.", color = Muted)
        if (weights.size >= 2) {
            val points = weights.takeLast(14).map { it.second }
            val low = points.min() - 1
            val high = points.max() + 1
            Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                val dx = size.width / (points.size - 1)
                points.zipWithNext().forEachIndexed { i, (a, b) ->
                    drawLine(
                        Green,
                        Offset(
                            i * dx,
                            size.height - ((a - low) / (high - low) * size.height).toFloat(),
                        ),
                        Offset(
                            (i + 1) * dx,
                            size.height - ((b - low) / (high - low) * size.height).toFloat(),
                        ),
                        strokeWidth = 5f,
                    )
                }
            }
            Text(
                "${weights.first().second} kg → ${weights.last().second} kg",
                fontWeight = FontWeight.SemiBold,
            )
        }
        Field("Today's weight (kg)", entry, { entry = it }, true)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                val w = entry.replace(',', '.').toDoubleOrNull()
                if (w == null || !w.isFinite() || w !in 30.0..250.0)
                    error = "Enter a weight between 30 and 250 kg."
                else {
                    store.logWeight(p.id, w)
                    entry = ""
                    error = null
                    onUpdate()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Save weight")
        }
        weights.takeLast(5).reversed().forEach { (date, w) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(date, color = Muted)
                Text("$w kg", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
